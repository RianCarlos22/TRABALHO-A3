window.addEventListener("DOMContentLoaded", () => {
  const urlParams = new URLSearchParams(window.location.search);
  const modoEdicao = urlParams.get("editar");

  if (modoEdicao === "true") {
    const dados = JSON.parse(localStorage.getItem("dadosUsuario"));
    if (dados) {
      document.getElementById("peso").value = dados.peso;
      document.getElementById("altura").value = dados.altura;
      document.getElementById("idade").value = dados.idade;
      document.getElementById("sexo").value = dados.sexo;
      document.getElementById("dieta").value = dados.dieta;

      const checkboxGroups = document.querySelectorAll(".checkbox-group");

      const preferenciasChecks = checkboxGroups[0].querySelectorAll("input[type='checkbox']");
      preferenciasChecks.forEach(input => {
        if (dados.preferencias.includes(input.value)) input.checked = true;
      });

      const restricoesChecks = checkboxGroups[1].querySelectorAll("input[type='checkbox']");
      restricoesChecks.forEach(input => {
        if (dados.restricoes.includes(input.value)) input.checked = true;
      });
    }
  }
});

document.getElementById("formCadastro").addEventListener("submit", function (e) {
  e.preventDefault();

  const peso = parseFloat(document.getElementById("peso").value);
  const altura = parseFloat(document.getElementById("altura").value);
  const idade = parseInt(document.getElementById("idade").value);
  const sexo = document.getElementById("sexo").value;
  const dieta = document.getElementById("dieta").value;

  if (!peso || !altura || !idade || !sexo || !dieta) {
    alert("Por favor, preencha todos os campos obrigatórios.");
    return;
  }

  const checkboxGroups = document.querySelectorAll(".checkbox-group");

  const preferencias = Array.from(checkboxGroups[0].querySelectorAll("input[type='checkbox']"))
    .filter(el => el.checked)
    .map(el => el.value);

  const restricoes = Array.from(checkboxGroups[1].querySelectorAll("input[type='checkbox']"))
    .filter(el => el.checked)
    .map(el => el.value);

  if (restricoes.includes("Nenhuma") && restricoes.length > 1) {
    alert('Selecione "Nenhuma" sozinha ou outras opções, mas não ambas.');
    return;
  }

  const alturaM = altura / 100;
  const imc = peso / (alturaM * alturaM);

  let tmb;
  if (sexo === "Masculino") {
    tmb = 10 * peso + 6.25 * altura - 5 * idade + 5;
  } else {
    tmb = 10 * peso + 6.25 * altura - 5 * idade - 161;
  }

  const agua = peso * 35;

  const dados = {
    peso,
    altura,
    idade,
    sexo,
    dieta,
    preferencias,
    restricoes,
    imc: imc.toFixed(2),
    tmb: tmb.toFixed(2),
    agua: agua.toFixed(0)
  };

  localStorage.setItem("dadosUsuario", JSON.stringify(dados));

  window.location.href = "resultado.html";
});
