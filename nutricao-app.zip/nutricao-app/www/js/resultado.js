window.addEventListener("DOMContentLoaded", () => {
  const dados = JSON.parse(localStorage.getItem("dadosUsuario"));

  if (!dados) {
    alert("Nenhum dado encontrado. Por favor, preencha o cadastro.");
    window.location.href = "cadastro.html";
    return;
  }

  // Preencher dados do usuário
  document.getElementById("peso").textContent = dados.peso;
  document.getElementById("altura").textContent = dados.altura;
  document.getElementById("idade").textContent = dados.idade;
  document.getElementById("sexo").textContent = dados.sexo;
  document.getElementById("dieta").textContent = dados.dieta;

  document.getElementById("preferencias").textContent = dados.preferencias.length > 0 ? dados.preferencias.join(", ") : "Nenhuma";
  document.getElementById("restricoes").textContent = dados.restricoes.length > 0 ? dados.restricoes.join(", ") : "Nenhuma";

  // Preencher dados calculados
  document.getElementById("tmb").textContent = `${dados.tmb} kcal`;
  document.getElementById("imc").textContent = dados.imc;

  // Classificação do IMC
  const imc = parseFloat(dados.imc);
  let classificacao = "";

  if (imc < 18.5) classificacao = "Abaixo do peso";
  else if (imc < 24.9) classificacao = "Peso normal";
  else if (imc < 29.9) classificacao = "Sobrepeso";
  else if (imc < 34.9) classificacao = "Obesidade Grau I";
  else if (imc < 39.9) classificacao = "Obesidade Grau II";
  else classificacao = "Obesidade Grau III";

  document.getElementById("classificacaoIMC").textContent = classificacao;

  document.getElementById("agua").textContent = `${dados.agua}`;

  // Gráfico de consumo de água
  const ctx = document.getElementById("graficoAgua").getContext("2d");
  new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Água Recomend. (ml)", "Faltando"],
      datasets: [{
        data: [dados.agua, 3000 - dados.agua],
        backgroundColor: ["#4bc0c0", "#e0e0e0"]
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: "bottom"
        },
        title: {
          display: true,
          text: "Consumo Diário de Água"
        }
      }
    }
  });

  // Redirecionar para edição
  document.getElementById("btnEditar").addEventListener("click", () => {
    window.location.href = "cadastro.html?editar=true";
  });

  // Sugestões de alimentos (opcional, pode ser melhorado)
  const alimentos = {
    "Emagrecimento": ["Frango grelhado", "Salada verde", "Ovos cozidos", "Abobrinha", "Chá verde"],
    "Hipertrofia": ["Arroz integral", "Feijão", "Carne vermelha magra", "Batata doce", "Banana", "Ovos"]
  };

  const container = document.getElementById("alimentosContainer");
  const lista = alimentos[dados.objetivo] || ["Consulte um nutricionista para sugestões personalizadas."];

  container.innerHTML = "<ul>" + lista.map(alimento => `<li>${alimento}</li>`).join("") + "</ul>";
});
