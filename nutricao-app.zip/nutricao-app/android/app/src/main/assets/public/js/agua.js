const metaLitros = () => {
  const dados = JSON.parse(localStorage.getItem("dadosUsuario"));
  if (!dados || !dados.peso) return 2;
  return (dados.peso * 35 / 1000).toFixed(2); // em litros
};

const mostrarMeta = () => {
  document.getElementById("metaAgua").innerText = `Meta diária: ${metaLitros()} L de água`;
};

// Função auxiliar para pegar os últimos 7 dias
const gerarDatas = () => {
  const datas = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    datas.push(d.toLocaleDateString('pt-BR', { weekday: 'short' }));
  }
  return datas;
};

// Carrega ou inicializa o histórico
const getHistorico = () => {
  const historico = JSON.parse(localStorage.getItem("historicoAgua"));
  if (historico && historico.length === 7) return historico;
  return new Array(7).fill(0);
};

// Atualiza o histórico com o valor de hoje
function registrarConsumo() {
  const copos = parseInt(document.getElementById("qtdHoje").value);
  if (isNaN(copos)) return;

  let historico = getHistorico();
  historico.shift(); // remove o mais antigo
  historico.push(copos); // adiciona o de hoje
  localStorage.setItem("historicoAgua", JSON.stringify(historico));
  desenharGrafico(historico);
}

const desenharGrafico = (dados) => {
  const ctx = document.getElementById("graficoAgua").getContext("2d");
  if (window.grafico) window.grafico.destroy(); // caso reabra a página
  window.grafico = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: gerarDatas(),
      datasets: [{
        label: 'Copos (250ml)',
        data: dados,
        backgroundColor: '#4fc3f7'
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true,
          ticks: { stepSize: 1 }
        }
      }
    }
  });
};

// Inicialização
mostrarMeta();
desenharGrafico(getHistorico());
