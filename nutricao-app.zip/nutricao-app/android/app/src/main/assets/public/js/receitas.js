const dados = carregarDados("dadosUsuario");
const div = document.getElementById("receitas");

if (!dados || !dados.dieta) {
  div.innerHTML = "<p>Dados da dieta não encontrados.</p>";
} else {
  const receitas = {
    mediterranea: [
      {
        nome: "Salada Grega com Azeite",
        ingredientes: [
          "Tomate", "Pepino", "Azeitona preta", "Queijo feta", "Azeite de oliva extra virgem"
        ],
        preparo: "Misture todos os ingredientes em uma tigela e regue com azeite de oliva."
      },
      {
        nome: "Peixe Assado com Ervas",
        ingredientes: [
          "Filé de peixe (tilápia ou salmão)", "Alho", "Limão", "Ervas finas", "Azeite"
        ],
        preparo: "Tempere o peixe e asse por 25 minutos a 180°C."
      }
    ],
    lowcarb: [
      {
        nome: "Omelete de Espinafre",
        ingredientes: ["2 ovos", "Espinafre", "Queijo ralado", "Sal e pimenta"],
        preparo: "Bata os ovos, misture o espinafre e queijo e frite em uma frigideira antiaderente."
      },
      {
        nome: "Abobrinha Recheada",
        ingredientes: ["Abobrinha", "Carne moída", "Tomate picado", "Cebola", "Queijo ralado"],
        preparo: "Recheie a abobrinha com a carne refogada e leve ao forno com queijo por cima."
      }
    ],
    cetogenica: [
      {
        nome: "Avocado com Ovo",
        ingredientes: ["1 avocado", "1 ovo", "Sal, pimenta e azeite"],
        preparo: "Corte o avocado, retire parte do meio e coloque um ovo. Asse por 15 minutos."
      },
      {
        nome: "Frango com Creme de Leite",
        ingredientes: ["Peito de frango", "Creme de leite", "Alho e sal", "Azeite ou manteiga"],
        preparo: "Cozinhe o frango e adicione o creme de leite no final para formar um molho."
      }
    ],
    vegetariana: [
      {
        nome: "Estrogonofe de Grão-de-Bico",
        ingredientes: ["Grão-de-bico cozido", "Molho de tomate", "Creme de leite vegetal", "Cebola e alho"],
        preparo: "Refogue os ingredientes e finalize com o creme de leite vegetal."
      },
      {
        nome: "Panqueca de Aveia e Banana",
        ingredientes: ["1 banana", "2 colheres de aveia", "1 ovo"],
        preparo: "Misture tudo e frite em uma frigideira antiaderente até dourar dos dois lados."
      }
    ]
  };

  const dieta = dados.dieta.toLowerCase();
  const receitasSelecionadas = receitas[dieta];

  if (!Array.isArray(receitasSelecionadas)) {
    div.innerHTML = "<p>Nenhuma receita disponível para essa dieta.</p>";
    return;
  }

  div.innerHTML = receitasSelecionadas.map(r => `
    <section class="card-receita">
      <h2>${r.nome}</h2>
      <p><strong>Ingredientes:</strong></p>
      <ul>${r.ingredientes.map(i => `<li>${i}</li>`).join("")}</ul>
      <p><strong>Modo de Preparo:</strong> ${r.preparo}</p>
    </section>
  `).join("");
}
