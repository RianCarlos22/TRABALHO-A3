function interpretarIMC(imc) {
  if (imc < 18.5) return "Abaixo do peso";
  if (imc < 25) return "Peso normal";
  if (imc < 30) return "Sobrepeso";
  return "Obesidade";
}

const dados = JSON.parse(localStorage.getItem("dadosUsuario"));

if (dados) {

function editarCadastro() {
  window.location.href = "cadastro.html?editar=true";
}

  const resultadoDiv = document.getElementById("resultado");

  // Bloco de resultados principais
  resultadoDiv.innerHTML = `
    <p><strong>Peso:</strong> ${dados.peso} kg</p>
    <p><strong>Altura:</strong> ${dados.altura} cm</p>
    <p><strong>Idade:</strong> ${dados.idade} anos</p>
    <p><strong>Sexo:</strong> ${dados.sexo}</p>
    <p><strong>Dieta Escolhida:</strong> ${dados.dieta}</p>
    <p><strong>Objetivo:</strong> ${dados.objetivo}</p>
    <hr/>
    <p><strong>TMB (Taxa Metabólica Basal):</strong> ${dados.tmb} kcal</p>
    <p><strong>IMC:</strong> ${dados.imc} (${interpretarIMC(dados.imc)})</p>
    <p><strong>Consumo diário de água:</strong> ${dados.agua} ml</p>
    <hr/>
    <p><strong>Preferências alimentares:</strong> ${dados.preferencias.join(", ") || "Nenhuma"}</p>
    <p><strong>Restrições alimentares:</strong> ${dados.restricoes.join(", ") || "Nenhuma"}</p>
    <hr/>
    <h2>Recomendações Alimentares</h2>
    <div id="alimentosContainer"></div>
    <p style="text-align:center; margin-top: 20px;">
      <button onclick="editarCadastro()">Editar Dados</button>
    </p>
  `;

  const ctx = document.getElementById('graficoAgua').getContext('2d');
    const litrosPorDia = (dados.agua / 1000).toFixed(2); // Convertendo ml para litros

    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Consumo Recomendado'],
        datasets: [{
          label: 'Água (litros/dia)',
          data: [litrosPorDia],
          backgroundColor: '#42a5f5',
          borderRadius: 10
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: (value) => value + ' L'
            }
          }
        },
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            callbacks: {
              label: (context) => context.parsed.y + ' litros'
            }
          }
        }
      }
    });

  // Recomendações por dieta
  const alimentos = {
    "Mediterrânea": {
      Proteínas: ["Peixes", "Frango", "Ovo"],
      Legumes: ["Abobrinha", "Berinjela", "Pimentão"],
      Verduras: ["Espinafre", "Rúcula", "Alface"],
      Carboidratos: ["Grãos integrais", "Batata", "Arroz integral"]
    },
    "Low Carb": {
      Proteínas: ["Carne magra", "Frango", "Ovos"],
      Legumes: ["Couve-flor", "Brócolis", "Abobrinha"],
      Verduras: ["Alface", "Espinafre", "Couve"],
      Carboidratos: ["Batata-doce (moderação)", "Chia", "Castanhas"]
    },
    "Cetogênica": {
      Proteínas: ["Bacon", "Frango", "Ovos"],
      Legumes: ["Abobrinha", "Cogumelos", "Espinafre"],
      Verduras: ["Couve", "Acelga", "Rúcula"],
      Carboidratos: ["Abacate", "Coco", "Linhaça"]
    },
    "Vegetariana": {
      Proteínas: ["Ovos", "Tofu", "Lentilhas"],
      Legumes: ["Abóbora", "Cenoura", "Berinjela"],
      Verduras: ["Alface", "Rúcula", "Agrião"],
      Carboidratos: ["Arroz integral", "Feijão", "Batata"]
    }
  };

  const container = document.getElementById("alimentosContainer");
  const dieta = dados.dieta;

  if (alimentos[dieta]) {
    for (let categoria in alimentos[dieta]) {
      const titulo = document.createElement("h3");
      titulo.textContent = categoria;
      container.appendChild(titulo);

      const ul = document.createElement("ul");
      alimentos[dieta][categoria].forEach(item => {
        const li = document.createElement("li");
        li.textContent = item;
        ul.appendChild(li);
      });
      container.appendChild(ul);
    }
  }

} else {
  document.getElementById("resultado").innerHTML = "<p>Dados não encontrados. Retorne à página inicial.</p>";
}
