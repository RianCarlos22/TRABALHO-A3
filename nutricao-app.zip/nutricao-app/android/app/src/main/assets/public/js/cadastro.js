// Preenche o formulário com dados do localStorage se estiver no modo edição
window.addEventListener("DOMContentLoaded", () => {
  const urlParams = new URLSearchParams(window.location.search);
  const modoEdicao = urlParams.get("editar");

  if (modoEdicao === "true") {
    const dados = JSON.parse(localStorage.getItem("dadosUsuario"));
    if (dados) {
      document.getElementById("peso").value = dados.peso;
      document.getElementById("altura").value = dados.altura;
      document.getElementById("idade").value = dados.idade;
      document.getElementById("sexo").value = dados.sexo;
      document.getElementById("dieta").value = dados.dieta;
      document.getElementById("objetivo").value = dados.objetivo;

      // Checkboxes - Preferências
      document.querySelectorAll(".checkbox-group").forEach((group, i) => {
        const inputs = group.querySelectorAll("input[type='checkbox']");
        if (i === 0) {
          // Preferências
          inputs.forEach(el => {
            if (dados.preferencias.includes(el.value)) el.checked = true;
          });
        } else if (i === 1) {
          // Restrições
          inputs.forEach(el => {
            if (dados.restricoes.includes(el.value)) el.checked = true;
          });
        }
      });
    }
  }
});

document.getElementById("formCadastro").addEventListener("submit", function (e) {
  e.preventDefault();

  // Pegando valores
  const peso = parseFloat(document.getElementById("peso").value);
  const altura = parseFloat(document.getElementById("altura").value);
  const idade = parseInt(document.getElementById("idade").value);
  const sexo = document.getElementById("sexo").value;
  const dieta = document.getElementById("dieta").value;
  const objetivo = document.getElementById("objetivo").value;

  if (!sexo) {
    alert("Por favor, selecione o sexo.");
    return;
  }

  // Pegando checkboxes
  const preferencias = Array.from(document.querySelectorAll(".checkbox-group:first-of-type input[type='checkbox']"))
    .filter(el => el.checked)
    .map(el => el.value);

  const restricoes = Array.from(document.querySelectorAll(".checkbox-group:nth-of-type(2) input[type='checkbox']"))
    .filter(el => el.checked)
    .map(el => el.value);

  // Validação campos obrigatórios
  if (!peso || !altura || !idade || !sexo || !dieta || !objetivo) {
    alert("Por favor, preencha todos os campos obrigatórios.");
    return;
  }

  // Validação restrições - "Nenhuma" não pode estar com outras opções marcadas
  if (restricoes.includes("Nenhuma") && restricoes.length > 1) {
    alert('Selecione "Nenhuma" somente, ou outras restrições, mas não as duas opções juntas.');
    return;
  }

  // Cálculo do TMB (Mifflin-St Jeor)
  let tmb;
  if (sexo.toLowerCase() === "masculino") {
    tmb = 10 * peso + 6.25 * altura - 5 * idade + 5;
  } else {
    tmb = 10 * peso + 6.25 * altura - 5 * idade - 161;
  }

  // Cálculo do IMC
  const alturaM = altura / 100;
  const imc = peso / (alturaM * alturaM);

  // Consumo diário de água
  const agua = peso * 35; // em ml

  // Armazenando tudo no localStorage
  const dados = {
    peso,
    altura,
    idade,
    sexo,
    dieta,
    objetivo,
    preferencias,
    restricoes,
    tmb: tmb.toFixed(2),
    imc: imc.toFixed(2),
    agua: agua.toFixed(0)
  };

  localStorage.setItem("dadosUsuario", JSON.stringify(dados));

  // Redireciona para a página de resultado
  window.location.href = "resultado.html";
});
