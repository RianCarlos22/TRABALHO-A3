// calculos.js

function calcularTMB(peso, altura, idade, sexo) {
  if (sexo.toLowerCase() === "masculino") {
    return 10 * peso + 6.25 * altura - 5 * idade + 5;
  } else if (sexo.toLowerCase() === "feminino") {
    return 10 * peso + 6.25 * altura - 5 * idade - 161;
  } else {
    return 0; // ou lance erro se quiser
  }
}

function calcularIMC(peso, altura) {
  return peso / ((altura / 100) ** 2);
}

function interpretarIMC(imc) {
  if (imc < 18.5) return "Abaixo do peso";
  if (imc < 25) return "Peso normal";
  if (imc < 30) return "Sobrepeso";
  return "Obesidade";
}

function calcularConsumoAgua(peso) {
  return peso * 35;
}
