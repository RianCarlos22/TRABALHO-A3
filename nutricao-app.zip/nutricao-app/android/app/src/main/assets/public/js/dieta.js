const dados = JSON.parse(localStorage.getItem("dadosUsuario"));
const lista = document.getElementById("recomendacoes");

if (!dados || !dados.dieta) {
  lista.innerHTML = "<p>Informações não encontradas. Volte para a tela inicial.</p>";
} else {
  const restricoes = dados.restricoes || [];

  const alimentosPorDieta = {
    mediterranea: {
      Proteínas: [
        { nome: "Peixe grelhado", kcal: 150, qtde: "100g" },
        { nome: "Ovos cozidos", kcal: 70, qtde: "1 un" }
      ],
      Carboidratos: [
        { nome: "Arroz integral", kcal: 110, qtde: "1/2 xíc." },
        { nome: "Pão integral", kcal: 100, qtde: "1 fatia" }
      ],
      Legumes: [
        { nome: "Abobrinha", kcal: 20, qtde: "1/2 xíc." },
        { nome: "Berinjela", kcal: 25, qtde: "1/2 xíc." }
      ],
      Verduras: [
        { nome: "Alface", kcal: 10, qtde: "1 xíc." },
        { nome: "Espinafre", kcal: 15, qtde: "1/2 xíc." }
      ]
    },
    lowcarb: {
      Proteínas: [
        { nome: "Frango grelhado", kcal: 165, qtde: "100g" },
        { nome: "Tofu", kcal: 80, qtde: "100g" }
      ],
      Carboidratos: [
        { nome: "Abóbora", kcal: 45, qtde: "1/2 xíc." },
        { nome: "Couve-flor", kcal: 25, qtde: "1/2 xíc." }
      ],
      Legumes: [
        { nome: "Chuchu", kcal: 20, qtde: "1/2 xíc." },
        { nome: "Repolho", kcal: 20, qtde: "1/2 xíc." }
      ],
      Verduras: [
        { nome: "Almeirão", kcal: 13, qtde: "1 xíc." },
        { nome: "Rúcula", kcal: 5, qtde: "1 xíc." }
      ]
    },
    cetogenica: {
      Proteínas: [
        { nome: "Carne bovina", kcal: 200, qtde: "100g" },
        { nome: "Ovos fritos", kcal: 90, qtde: "1 un" }
      ],
      Carboidratos: [
        { nome: "Abacate", kcal: 160, qtde: "1/2 un" },
        { nome: "Cogumelos", kcal: 20, qtde: "1/2 xíc." }
      ],
      Legumes: [
        { nome: "Espinafre", kcal: 15, qtde: "1/2 xíc." },
        { nome: "Aspargos", kcal: 20, qtde: "1/2 xíc." }
      ],
      Verduras: [
        { nome: "Alface", kcal: 10, qtde: "1 xíc." },
        { nome: "Agrião", kcal: 7, qtde: "1 xíc." }
      ]
    },
    vegetariana: {
      Proteínas: [
        { nome: "Grão-de-bico", kcal: 160, qtde: "1/2 xíc." },
        { nome: "Lentilha", kcal: 180, qtde: "1/2 xíc." }
      ],
      Carboidratos: [
        { nome: "Batata-doce", kcal: 90, qtde: "1/2 xíc." },
        { nome: "Arroz integral", kcal: 110, qtde: "1/2 xíc." }
      ],
      Legumes: [
        { nome: "Cenoura", kcal: 25, qtde: "1/2 xíc." },
        { nome: "Beterraba", kcal: 35, qtde: "1/2 xíc." }
      ],
      Verduras: [
        { nome: "Couve", kcal: 20, qtde: "1 xíc." },
        { nome: "Espinafre", kcal: 15, qtde: "1/2 xíc." }
      ]
    }
  };

  const dieta = dados.dieta.toLowerCase();
  const categorias = alimentosPorDieta[dieta];

  let html = "";

  for (let categoria in categorias) {
    html += `<h2>${categoria}</h2><ul>`;
    categorias[categoria].forEach(alimento => {
      const excluido = restricoes.some(r => alimento.nome.toLowerCase().includes(r));
      if (!excluido) {
        html += `<li><strong>${alimento.nome}</strong> — ${alimento.qtde}, ${alimento.kcal} kcal</li>`;
      }
    });
    html += "</ul>";
  }

  lista.innerHTML = html;
}
