// Verifica se o navegador suporta localStorage
function storageDisponivel() {
  try {
    const teste = '__test__';
    localStorage.setItem(teste, teste);
    localStorage.removeItem(teste);
    return true;
  } catch (e) {
    console.error("localStorage não está disponível.");
    return false;
  }
}

// Salvar dados com segurança
function salvarDados(chave, dados) {
  if (!storageDisponivel()) return;
  try {
    const json = JSON.stringify(dados);
    localStorage.setItem(chave, json);
  } catch (e) {
    console.error("Erro ao salvar dados:", e);
  }
}

// Carregar dados com segurança
function carregarDados(chave) {
  if (!storageDisponivel()) return null;
  try {
    const json = localStorage.getItem(chave);
    return json ? JSON.parse(json) : null;
  } catch (e) {
    console.error("Erro ao carregar dados:", e);
    return null;
  }
}

// Remover dados por chave
function removerDados(chave) {
  if (!storageDisponivel()) return;
  try {
    localStorage.removeItem(chave);
  } catch (e) {
    console.error("Erro ao remover dados:", e);
  }
}

// Atualizar dados (mescla com dados existentes)
function atualizarDados(chave, novosDados) {
  if (!storageDisponivel()) return;
  try {
    const dadosAtuais = carregarDados(chave) || {};
    const atualizados = { ...dadosAtuais, ...novosDados };
    salvarDados(chave, atualizados);
  } catch (e) {
    console.error("Erro ao atualizar dados:", e);
  }
}
